<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LPGCylinder extends Model
{
    protected $guarded = [' '];
}
