<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FuelType extends Model
{
    // Fillable for Mass Assignment
    protected $guarded = [' '];
}
