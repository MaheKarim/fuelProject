@extends('user.home')

@section('content')
    We Are Coming Soon
@endsection
