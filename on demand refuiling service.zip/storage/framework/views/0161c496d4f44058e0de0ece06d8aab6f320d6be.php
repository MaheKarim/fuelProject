<?php $__env->startSection('content'); ?>
 <h1 class="mt-4">LPG Delivery</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active" > Dashboard </li>
        <li class="breadcrumb-item active">LPG Delivery</li>
    </ol>
    <!-- Notification Start Here -->
    <?php if(session()->has('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session()->get('error')); ?>

        </div>
    <?php elseif(session()->has('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session()->get('success')); ?>

        </div>
    <?php endif; ?>
    <!-- Notification End Here -->

    <!-- error message -->
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <!-- error message end -->

    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-table ml-1"></i>
            LPG Delivery Form
        </div>

        <div class="card-body">
            <form method="POST" action="<?php echo e(route('user.lpgStore')); ?>">
            <?php echo csrf_field(); ?>
                    <div class="form-group form-focus">
                        <label class="focus-label">Select LPG Name && Type</label>
                        <select name="cylinder_name_id" class="form-control select">
                            <?php ($lpgdeliveries= \App\LPGCylinder::all()); ?>
                            <?php $__currentLoopData = $lpgdeliveries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>" <?php echo e(old('cylinder_name_id') == $item->id ? 'selected' : ''); ?>><?php echo e($item->cylinder_name); ?>   --   <?php echo e($item->cylinder_size); ?> Size Bottle   --   <?php echo e($item->cylinder_price); ?>  BDT</option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                <div class="form-group">
                    <label for="exampleInputEmail1">Delivery Address</label>
                    <input type="text" class="form-control" name="address" placeholder="Delivery Address">
                </div>
                <div class="form-row">
                    <div class="form-group form-focus col-md-6">
                        <label class="focus-label">Select Delivery Priority</label>
                        <select name="priority_name_id" class="form-control select">
                            <?php ($priorities = \App\Priority::all()); ?>
                            <?php $__currentLoopData = $priorities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $priority): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($priority->id); ?>" <?php echo e(old('priority_name_id') == $item->id ? 'selected' : ''); ?>><?php echo e($priority->priority_name); ?> </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-table ml-1"></i>
            LPG Delivery Sheet
        </div>

        <div class="card-body">
            <table class="table">
                <thead>
                <tr>

                    <th scope="col">LPG / Cylider Name</th>
                    <th scope="col">Address</th>
                    <th scope="col">Priority</th>
                    <th scope="col">Created At</th>
                    <th scope="col">Report</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $lpgDeliveries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->Cylinder->cylinder_name); ?> -   <?php echo e($item->Cylinder->cylinder_size); ?></td>
                    <td><?php echo e($item->address); ?></td>
                    <td><?php echo e($item->Priority->priority_name); ?></td>
                    <td> <?php echo e(date('d-m-Y', strtotime($item->created_at))); ?> </td>
                    <td>
                      <button type="button" class="btn btn-warning">Pending</button>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fuel_request-main\resources\views/user/lpg/index.blade.php ENDPATH**/ ?>