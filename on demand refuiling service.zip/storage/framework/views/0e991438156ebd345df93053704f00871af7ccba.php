<?php $__env->startSection('content'); ?>
    <h1 class="mt-4">Refuelling For</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item " > Dashboard </li>
        <li class="breadcrumb-item active">Refuelling For</li>
    </ol>

    <!-- Notification Start Here -->
    <?php if(session()->has('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session()->get('error')); ?>

        </div>
    <?php endif; ?>
    <!-- Notification End Here -->
    <!-- Notification Start Here -->
    <?php if(session()->has('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session()->get('success')); ?>

        </div>
    <?php endif; ?>
    <!-- Notification End Here -->

    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-table ml-1"></i>
            Refuelling Table
            <a class="btn btn-success float-right" href="<?php echo e(route('admin.refuelling.create')); ?>"><i class="fa fa-plus-circle" aria-hidden="true"></i>  Add   Refuelling </a>
        </div>

        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                    <tr>
                        <th>Refuelling For</th>
                        <th>Created At</th>
                        <th>Updated At</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tfoot>
                    <tr>
                        <th>Refuelling For</th>
                        <th>Created At</th>
                        <th>Updated At</th>
                        <th>Action</th>
                    </tr>
                    </tfoot>
                    <tbody>
                    <?php $__currentLoopData = $refuellings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $refuelling): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($refuelling->refueling_reason); ?></td>
                            <td><?php echo e($refuelling->created_at->diffForHumans()); ?></td>
                            <td><?php echo e($refuelling->updated_at->diffForHumans()); ?></td>
                            <td>
                                <a class="btn btn-warning btn-sm" href="<?php echo e(route('admin.refuelling.edit', $refuelling->id)); ?>">Edit</a>
                                <a class="btn btn-danger btn-sm" href="<?php echo e(route('admin.refuelling')); ?>"
                                   onclick="event.preventDefault();
                                       document.getElementById(
                                       'delete-form-<?php echo e($refuelling->id); ?>').submit();">Delete</a>
                            </td>
                            <form id="delete-form-<?php echo e($refuelling->id); ?>"
                                  + action="<?php echo e(route('admin.refuelling.destroy', $refuelling->id)); ?>"
                                  method="post">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            </form>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fuel_request-main\resources\views/admin/refuelling/show.blade.php ENDPATH**/ ?>