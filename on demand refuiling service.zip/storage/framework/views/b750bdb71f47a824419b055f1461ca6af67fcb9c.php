<?php $__env->startSection('content'); ?>

    <h1 class="mt-4">Fuel Delivery</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active" > Dashboard </li>
        <li class="breadcrumb-item active">Fuel Delivery</li>
    </ol>
    <!-- error message -->
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <!-- error message end -->
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-table ml-1"></i>
            Add Delivery Sheet
        </div>

        <div class="card-body">
            <form method="POST" action="<?php echo e(route('user.fuelDelivery.store')); ?>">
                <?php echo csrf_field(); ?>
                    <!-- Area Start -->
                    <div class="form-row">
                    <div class="form-group form-focus col-md-6">
                        <label class="focus-label">Select Fuel Type</label>
                        <select name="fuel_name_id" class="form-control select">
                            <?php ($fuels= \App\FuelType::all()); ?>
                            <?php $__currentLoopData = $fuels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fuel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($fuel->id); ?>" <?php echo e(old('fuel_name_id') == $fuel->id ? 'selected' : ''); ?>><?php echo e($fuel->fuel_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <!-- Area END -->
                    <!-- Area Start -->
                    <div class="form-group form-focus col-md-6">
                        <label class="focus-label">Refueling For</label>
                        <select name="refueling_for_id" class="form-control select">
                            <?php ($refuellings= \App\RefuelingFor::all()); ?>
                            <?php $__currentLoopData = $refuellings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $refuelling): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($refuelling->id); ?>" <?php echo e(old('refueling_for_id') == $refuelling->id ? 'selected' : ''); ?>><?php echo e($refuelling->refueling_reason); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    </div>
                    <!-- Area END -->

                    <div class="form-group">
                        <label for="exampleInputEmail1">Delivery Address</label>
                        <input type="text" class="form-control" name="delivery_address" placeholder="Delivery Address">
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label for="exampleInputEmail1">Date Time</label>
                            <input type="datetime-local" class="form-control" name="booking_date">
                        </div>
                    <div class="form-group col-md-4">
                        <label for="phn">PHN Number</label>
                        <input type="number" class="form-control" name="phn_number" placeholder="PHN Number ex: 01303062727 ">
                    </div>
                    <div class="form-group col-md-4">
                        <label for="phn">Quantity (Litre/L)</label>
                        <input type="number" class="form-control" name="quantity" placeholder=" 10 (minimum 5 Ltr.)">
                    </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label for="SetDelivery">Set Delivery Signal</label>
                            <select name="priority_name_id" class="form-control select">
                                <?php ($priorities = \App\Priority::all()); ?>
                                <?php $__currentLoopData = $priorities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $priority): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($priority->id); ?>" <?php echo e(old('priority_name_id') == $priority->id ? 'selected' : ''); ?>><?php echo e($priority->priority_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
    </div>


    <div class="card mb-4">
        <div class="card-header">
           Report For Fuel Delivery
        </div>
        <div class="card-body">
            <table class="table">
                <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Fuel Type</th>
                    <th scope="col">Refuelling For</th>
                    <th scope="col">Delivery Address</th>
                    <th scope="col">Date</th>
                    <th scope="col">Quantity</th>
                    <th scope="col">Report</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $deliveries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deliver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($deliver->id); ?></th>
                    <td><?php echo e($deliver->Fuel->fuel_name); ?></td>
                    <td><?php echo e($deliver->RefuellingName->refueling_reason); ?></td>
                    <td><?php echo e($deliver->delivery_address); ?></td>
                    <td> <?php echo e(date('d-m-Y', strtotime($deliver->booking_date))); ?> </td>
                    <td><?php echo e($deliver->quantity); ?></td>
                    <td>
                        <?php if($deliver->isApproved == 0): ?>
                            <button type="button" class="btn btn-warning">Pending</button>
                        <?php else: ?>
                            <button type="button" class="btn btn-success">Accept</button>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fuel_request-main\resources\views/user/fuel-delivery/index.blade.php ENDPATH**/ ?>