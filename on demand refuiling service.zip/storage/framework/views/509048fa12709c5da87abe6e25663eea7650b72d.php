<footer class="py-4 bg-light mt-auto">
    <div class="container-fluid">
        <div class="d-flex align-items-center justify-content-between small">
            <div class="text-muted">Copyright &copy; <?php echo e(env('APP_NAME')); ?> <?php echo e(now()->year); ?></div>
            <div>
                <a href="#">Privacy Policy</a>
                &middot;
                <a href="#">Terms &amp; Conditions</a>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\fuel_request-main\resources\views/admin/inc/footer.blade.php ENDPATH**/ ?>