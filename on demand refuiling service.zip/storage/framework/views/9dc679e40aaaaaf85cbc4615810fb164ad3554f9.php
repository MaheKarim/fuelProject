<?php $__env->startSection('content'); ?>
    <h1 class="mt-4">Fuel Delivery</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item " > Dashboard </li>
        <li class="breadcrumb-item active">Fuel Delivery</li>
    </ol>

    <!-- Notification Start Here -->
    <?php if(session()->has('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session()->get('error')); ?>

        </div>
    <?php elseif(session()->has('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session()->get('success')); ?>

        </div>
    <?php endif; ?>
    <!-- Notification End Here -->

    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-table ml-1"></i>
            Fuel Delivery Table
        </div>

        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                    <tr>
                        <th>User</th>
                        <th>Fuel Name</th>
                        <th>Booking Date</th>
                        <th>Delivery Priority</th>
                        <th>isApproved</th>
                        <th>Created At</th>
                        <th>Details</th>
                    </tr>
                    </thead>

                    <tbody>
                    <?php $__currentLoopData = $delivery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->user->name); ?></td>
                            <td><?php echo e($item->Fuel->fuel_name); ?></td>
                            <td><?php echo e(date('d-m-Y', strtotime($item->booking_date))); ?></td>
                            <td><?php echo e($item->Priority->priority_name); ?></td>
                            <td>
                                <?php if($item->isApproved == 0): ?>
                                    <button type="button" class="btn btn-warning">Pending</button>
                                <?php else: ?>
                                    <button type="button" class="btn btn-success">Accept</button>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($item->created_at->diffForHumans()); ?></td>
                            <td>
                                <a class="btn btn-info btn-sm" href="<?php echo e(route('admin.delivery.details', $item->id)); ?>">Details</a>
                                <a class="btn btn-warning btn-sm" href="<?php echo e(route('admin.deliveryEdit', $item->id)); ?>">Edit</a>
                                <a class="btn btn-danger btn-sm" href="<?php echo e(route('admin.fueldelivery')); ?>"
                                   onclick="event.preventDefault();
                                       document.getElementById(
                                       'delete-form-<?php echo e($item->id); ?>').submit();">Delete</a>
                            </td>
                            <form id="delete-form-<?php echo e($item->id); ?>"
                                  + action="<?php echo e(route('admin.deliveryDestroy', $item->id)); ?>"
                                  method="post">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            </form>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fuel_request-main\resources\views/admin/fuel-delivery/index.blade.php ENDPATH**/ ?>