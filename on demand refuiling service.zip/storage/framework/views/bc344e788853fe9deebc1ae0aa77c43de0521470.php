<?php $__env->startSection('content'); ?>
<h1 class="mt-4">Fuel Type</h1>
<ol class="breadcrumb mb-4">
    <li class="breadcrumb-item " > Dashboard </li>
    <li class="breadcrumb-item active">Fuel Type</li>
</ol>

<!-- Notification Start Here -->
<?php if(session()->has('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session()->get('error')); ?>

    </div>
<?php endif; ?>
<!-- Notification End Here -->
<!-- Notification Start Here -->
<?php if(session()->has('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('success')); ?>

    </div>
<?php endif; ?>
<!-- Notification End Here -->

        <div class="card mb-4">
            <div class="card-header">
                <i class="fas fa-table ml-1"></i>
                Fuel Table
                <a class="btn btn-success float-right" href="<?php echo e(route('admin.fueltype.create')); ?>"><i class="fa fa-plus-circle" aria-hidden="true"></i>  Add Fuel Type</a>
            </div>

            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Fuel Type</th>
                                <th>Created At</th>
                                <th>Updated At</th>
                                <th>Details</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>Fuel Type</th>
                                <th>Created At</th>
                                <th>Updated At</th>
                                <th>Details</th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php $__currentLoopData = $fuels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fuel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($fuel->fuel_name); ?></td>
                                <td><?php echo e($fuel->created_at->diffForHumans()); ?></td>
                                <td><?php echo e($fuel->updated_at->diffForHumans()); ?></td>
                                <td>
                                    <a class="btn btn-warning btn-sm" href="<?php echo e(route('admin.fueltype.edit', $fuel->id)); ?>">Edit</a>
                                    <a class="btn btn-danger btn-sm" href="<?php echo e(route('admin.fueltype')); ?>"
                                    onclick="event.preventDefault();
                                     document.getElementById(
                                       'delete-form-<?php echo e($fuel->id); ?>').submit();">Delete</a>
                                </td>
                                <form id="delete-form-<?php echo e($fuel->id); ?>"
                                    + action="<?php echo e(route('admin.fueltype.destroy', $fuel->id)); ?>"
                                    method="post">
                                  <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                              </form>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fuel_request-main\resources\views/admin/fuel_type/show.blade.php ENDPATH**/ ?>