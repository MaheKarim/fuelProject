<?php $__env->startSection('content'); ?>

    <h1 class="mt-4">Refuelling Reason</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active" > Dashboard </li>
        <li class="breadcrumb-item active">Refuelling Reason</li>
        <li class="breadcrumb-item ">Create</li>
    </ol>
    <!-- error message -->
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <!-- error message end -->
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-table ml-1"></i>
            Add Refuelling reason

        </div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('admin.refuelling.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="exampleInputEmail1">Refuelling reason</label>
                    <input type="text" class="form-control" name="refueling_reason" placeholder="Enter refueling reason">
                </div>

                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fuel_request-main\resources\views/admin/refuelling/create.blade.php ENDPATH**/ ?>